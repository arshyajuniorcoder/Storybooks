<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Story Book</title>
	<link rel="stylesheet" href="./styles/bootstrap/css/bootstrap.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="./styles/header.css">
	<link rel="stylesheet" href="./styles/story_style.css">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark justify-content-between">
	<div class="container">
		<a class="navbar-brand logo-title">
			<img src="icons/logo.png" class="d-inline-block align-top logo" alt="logo">
			<span>Story Book</span>
		</a>
		<form action="" method="post" class="form-inline">
			<button class="btn btn-sm btn-success mx-2" type="submit" name="login">LOGIN</button>
			<button class="btn btn-sm btn-primary" type="submit" name="signup">SIGN UP</button>
		</form>
	</div>
</nav>
<div class="container">
	<div class="row">
		<div class="col">
			<div class="card">
				<img src="./icons/logo.png" class="card-img-top">
				<div class="card-body">
					<div class="card-title text-center">
						<p>@storybook</p>
					</div>
					<div class="card-text text-center">
						Storybook launched in 2022 in direct response to the growing concern around Facebook and the
						amount of data it was
						collecting on its users. The network prides itself on prioritizing its users' privacy and
						security and, unlike Facebook,
						doesn’t collect user activity information to create an algorithmic activity feed at all.

						The Storybook network is accessible via a website. It works very similar to Facebook regarding
						its user profiles, feeds,
						posts, sharing, and groups.
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	if (isset($_POST["login"])) {
		header("Location: php/login.php");
	}
	if (isset($_POST["signup"])) {
		header("Location: php/signup.php");
	}
?>
</body>
</html>