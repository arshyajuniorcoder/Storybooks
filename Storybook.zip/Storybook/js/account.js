let show = document.querySelector(".show");
show.addEventListener("click", function () {
	let password = document.querySelector(".password");
	let newPassword = document.querySelector(".new-password");
	if (show.src.match("../icons/show-password.svg")) {
		show.src = "../icons/hide-password.svg";
		password.type = "text";
		newPassword.type = "text";
	} else {
		show.src = "../icons/show-password.svg";
		password.type = "password";
		newPassword.type = "password";
	}
});

let update = document.querySelector(".update");
update.addEventListener("click", function () {
	let newPass = document.querySelector(".new-pass-form");
	if (newPass.style.display === "flex") {
		newPass.style.display = "none";
	} else {
		newPass.style.display = "flex";
	}
});