let likeIcon = document.querySelectorAll(".like");
for (let i = 0; i < likeIcon.length; i++) {
	likeIcon[i].addEventListener("click", function () {
		if (likeIcon[i].src.match("../icons/heart-dislike.svg")) {
			likeIcon[i].src = "../icons/heart-like.svg";
		} else {
			likeIcon[i].src = "../icons/heart-dislike.svg";
		}
	});
}

let commentIcon = document.querySelectorAll(".comment");
for (let i = 0; i < commentIcon.length; i++) {
	commentIcon[i].addEventListener("click", function () {
		let commentBox = document.querySelectorAll(".comment-box");
		if (commentBox[i].style.display === "block") {
			commentBox[i].style.display = "none";
		} else {
			commentBox[i].style.display = "block";
		}
	});
}

let saveIcon = document.querySelectorAll(".save");
for (let i = 0; i < saveIcon.length; i++) {
	saveIcon[i].addEventListener("click", function () {
		if (saveIcon[i].src.match("../icons/unsave.svg")) {
			saveIcon[i].src = "../icons/save.svg";
		} else {
			saveIcon[i].src = "../icons/unsave.svg";
		}
	});
}

let follow = document.querySelectorAll(".follow");
for (let i = 0; i < follow.length; i++) {
	follow[i].addEventListener("click", function () {
		if (follow[i].className === "btn btn-sm btn-secondary shadow rounder follow") {
			follow[i].innerHTML = "FOLLOWING";
			follow[i].className = "btn btn-sm btn-primary shadow rounder follow";
			if (window.innerWidth <= 450) {
				follow[i].style.width = "70px";
			} else if (window.innerWidth > 450 && window.innerWidth <= 980) {
				follow[i].style.width = "105px";
			} else {
				follow[i].style.width = "120px";
			}
		} else {
			follow[i].innerHTML = "FOLLOW";
			follow[i].className = "btn btn-sm btn-secondary shadow rounder follow";
			if (window.innerWidth <= 450) {
				follow[i].style.width = "70px";
			} else if (window.innerWidth > 450 && window.innerWidth <= 980) {
				follow[i].style.width = "105px";
			} else {
				follow[i].style.width = "120px";
			}
		}
	});
}