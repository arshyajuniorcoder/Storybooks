let users = document.querySelectorAll(".users");
for (let i = 0; i < users.length; i++) {
	users[i].addEventListener("click", function () {
		location.reload();
		let usersBox = document.querySelector(".users-box");
		usersBox.style.display = "none";
		let userName = document.querySelectorAll(".users span");
		document.cookie = `selected_user=${userName[i].innerHTML}`;
	});
}