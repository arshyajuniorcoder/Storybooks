<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>MY ACCOUNT</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/menu.css">
	<link rel="stylesheet" href="../styles/account.css">
	<script src="../js/jquery-3.6.0.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
	include "../html/header.html";
	include "connectToDB.php";
	global $con;
	include "checkSignInUser.php";
	global $checked_sign;
	if ($checked_sign) {
	if (isset($_COOKIE["user-id"])) {
		include "menu.php";
		$user_id = $_COOKIE["user-id"];
		$select_query = "SELECT * FROM users WHERE user_id='$user_id'";
		$result = mysqli_query($con, $select_query);
	if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		?>
		<div class="container rounded bg-white mt-5">
			<div class="row">
				<div class="col-md-5 border-right">
					<div class="d-flex flex-column align-items-center text-center p-3 py-5">
						<img src="../icons/user-profile.svg" class="rounded-circle mt-5" width="40%">
						<span class="fs-5 font-weight-bold my-2">@<?= $row["user_name"] ?></span>
					</div>
				</div>
				<div class="col-md-6 border-right">
					<div class="p-3 py-5">
						<div class="d-flex justify-content-between align-items-center mb-3">
							<h4 class="text-right">Profile</h4>
						</div>
						<form action="" method="post">
							<div class="row mt-2">
								<div class="col-md-6">
									<label class="mb-2 labels">First Name
										<span class="optional">(optional)</span>
									</label>
									<input type="text"
									       class="form-control"
									       placeholder="first name"
									       name="first-name"
									       value="<?= $row['first_name'] ?>"
									>
								</div>
								<div class="col-md-6">
									<label class="mb-2 labels">Last Name
										<span class="optional">(optional)</span>
									</label>
									<input type="text"
									       class="form-control"
									       placeholder="last name"
									       name="last-name"
									       value="<?= $row['last_name'] ?>"
									>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12 mt-3">
									<label class="mb-2 labels">Email
										<span class="optional">(optional)</span>
									</label>
									<input type="text"
									       class="form-control"
									       placeholder="email"
									       name="email"
									       value="<?= $row['email'] ?>">
								</div>
								<div class="col-md-12 mt-3">
									<label class="mb-2 labels">Username</label>
									<input type="text"
									       class="form-control"
									       placeholder="username"
									       value="<?= $row['user_name'] ?>"
									       disabled
									       readonly
									>
								</div>
								<div class="col-md-12 mt-3">
									<label class="mb-2 labels">Phone No.
										<span class="optional">(optional)</span>
									</label>
									<input type="text"
									       class="form-control"
									       placeholder="phone number"
									       name="phone"
									       value="<?= $row['phone_no'] ?>"
									>
								</div>
								<div class="col-md-12 mt-3">
									<label class="mb-2 labels">Gender
										<span class="optional">(optional)</span>
									</label>
									<select class="form-select" name="gender">
										<option>Choose your gender</option>
										<option value="female"
												<?php
													$gender_db = $row["gender"];
													if ($gender_db == "female") echo "selected='selected'";
												?>>
											Female
										</option>
										<option value="male"
												<?php
													if ($gender_db == "male") echo 'selected="selected"';
												?>>
											Male
										</option>
										<option value="other"
												<?php
													if ($gender_db == "other") echo 'selected="selected"';
												?>>
											Other
										</option>
									</select>
								</div>
								<div class="row mt-3">
									<div class="col-9 pass-form">
										<label class="mb-2 labels">Password</label>
										<input type="password"
										       class="form-control password"
										       placeholder="password"
										       name="password"
										       value="<?= $row['pass_word'] ?>"
										>
										<img src="../icons/show-password.svg" class="icons show"
										     alt="show password">
									</div>
									<div class="col-2">
										<img src="../icons/update-password.svg" class="icons update"
										     alt="update password">
									</div>
								</div>
							</div>
							<div class="row new-pass-form">
								<div class="col-12 mt-2">
									<label class="mb-2 labels">New Password
									</label>
									<input type="password"
									       class="form-control new-password"
									       placeholder="new password"
									       name="new-password"
									>
								</div>
								<div class="col-12 mt-2">
									<label class="mb-2 labels">Confirm New
									</label>
									<input type="password"
									       class="form-control new-password"
									       placeholder="confirm password"
									       name="confirm-new-password"
									>
								</div>
							</div>
							<div class="mt-5 text-center">
								<button class="btn btn-primary profile-button" type="submit" name="save">
									Save Profile
								</button>
							</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	<?php
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "0 results.",
				icon: "warning",
				button: "OK",
			});
		</script>
	<?php
		}
		if (isset($_POST["save"])) {
		$pass_word = $_POST["password"];
		$new_password = $_POST["new-password"];
		$confirm_password = $_POST["confirm-new-password"];
		$first_name = $_POST["first-name"];
		$last_name = $_POST["last-name"];
		$email = $_POST["email"];
		$phone_no = $_POST["phone"];
		$gender = $_POST["gender"];
		if ($new_password) {
		if ($new_password == $confirm_password) {
		$update_user = "UPDATE users SET 
                 				pass_word='$new_password', first_name='$first_name', last_name='$last_name', 
                 				email='$email', phone_no='$phone_no', gender='$gender'
                 				WHERE user_id='$user_id'";
		if (mysqli_query($con, $update_user)) {
	?>
		<script>
			swal({
				title: "",
				text: "Record updated successfully.",
				icon: "success",
				button: "OK",
			});
		</script>
	<?php
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Error updating record.",
				icon: "error",
				button: "OK",
			});
		</script>
	<?php
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Passwords are not the same.",
				icon: "warning",
				button: "Try again",
			});
		</script>
	<?php
		}
		} else {
		$update_user = "UPDATE users SET 
                 				first_name='$first_name', last_name='$last_name', 
                 				email='$email', phone_no='$phone_no', gender='$gender'
                 				WHERE user_id='$user_id'";
		if (mysqli_query($con, $update_user)) {
	?>
		<script>
			swal({
				title: "",
				text: "Record updated successfully.",
				icon: "success",
				button: "OK",
			});
		</script>
	<?php
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Error updating record.",
				icon: "warning",
				button: "OK",
			});
		</script>
	<?php
		}
		}
		}
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Please login first.",
				icon: "warning",
				button: "OK",
			}).then(function () {
				location.href = "./login.php";
			});
		</script>
		<?php
	}
	mysqli_close($con);
?>
<script src="../js/account.js"></script>
<script !src="">
	$('.menu').on('click', function () {
		$('.list').toggleClass('hidden');
	});
</script>
</body>
</html>