<?php
	if (isset($_COOKIE["user-name"]) && isset($_COOKIE["pass-word"])) {
		$checkUser = $_COOKIE["user-name"];
		$checkPass = $_COOKIE["pass-word"];
		include "connectToDB.php";
		global $con;
		$select_checked = "SELECT * FROM users WHERE user_name='$checkUser' AND pass_word='$checkPass'";
		$result = mysqli_query($con, $select_checked);
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$checked_sign = $row["user_id"];
			}
		}
	}