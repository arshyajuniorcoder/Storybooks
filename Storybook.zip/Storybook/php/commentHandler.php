<?php
	include "connectToDB.php";
	global $con;
	$comment_text = $_POST["comment_text"];
	$comment_id = $_POST["comment_id"];
	$user_id = $_POST["user_id"];
	$insert_comment = "INSERT INTO new_comments(comments, user_id, img_id)
						VALUES ('$comment_text', '$user_id', '$comment_id')";
	mysqli_query($con, $insert_comment);