<?php
//	$servername = "sql100.epizy.com";
//	$username = "epiz_31543548";
//	$password = "UTGHdS3709TS2O";
//	$dbname = "epiz_31543548_storybook";
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "storybook_project";
	$con = mysqli_connect($servername, $username, $password, $dbname);
	if (!$con) {
		?>
		<script>
			swal({
				title: "",
				text: "Connection failed.",
				icon: "warning",
				button: "Try again",
			});
		</script>
		<?php
	}
?>