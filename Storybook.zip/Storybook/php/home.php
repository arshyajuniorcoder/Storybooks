<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>HOME</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/menu.css">
	<link rel="stylesheet" href="../styles/home.css">
	<script src="../js/jquery-3.6.0.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
	include "../html/header.html";
	include "connectToDB.php";
	global $con;
	include "checkSignInUser.php";
	global $checked_sign;
	if ($checked_sign) {
	if (isset($_COOKIE["user-id"])) {
		include "menu.php";
		$user_id = $_COOKIE["user-id"];
		$user_name = $_COOKIE["user-name"];
		?>
		<script>
			$(function () {
				let likeIcon = document.querySelectorAll(".like");
				for (let i = 0; i < likeIcon.length; i++) {
					likeIcon[i].addEventListener("click", function () {
						let likeID = document.querySelectorAll("#img-id");
						$.ajax({
							type: "post",
							url: "likeHandler.php",
							data: {
								user_id: "<?= $user_id ?>",
								like_id: `${likeID[i].value}`
							},
							success: (respond) => {
								let countLike = document.querySelectorAll(".count_like");
								countLike[i].innerHTML = respond;
							}
						});
					});
				}
				let addComment = document.querySelectorAll(".add-comt");
				for (let i = 0; i < addComment.length; i++) {
					addComment[i].addEventListener("click", function () {
						let comtID = document.querySelectorAll("#img-id");
						let commentText = document.querySelectorAll(".new-comment");
						$.ajax({
							type: "post",
							url: "commentHandler.php",
							data: {
								comment_id: `${comtID[i].value}`,
								comment_text: `${commentText[i].value}`,
								user_id: "<?= $user_id ?>"
							},
							success: () => {
								let parent = document.querySelectorAll(".sub-comment");
								let user = document.createElement("p");
								let comtText = document.createElement("span");
								user.className = "sub-user-comment";
								user.innerHTML = "<?= $user_name ?>";
								comtText.className = "new-sub-comment";
								comtText.innerHTML = commentText[i].value;
								parent[i].appendChild(user);
								user.appendChild(comtText);
								commentText[i].value = "";
							}
						});
					});
				}
			});
		</script>
	<?php
		$select_query = "SELECT * FROM posts INNER JOIN users ON (posts.user_id = users.user_id)
							WHERE posts.user_id='$user_id' ORDER BY post_time DESC";
		$result = mysqli_query($con, $select_query);
		if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
		$post_time = strtotime($row["post_time"]);
		$customize_time = date("l, d F, Y", $post_time);
	?>
		<div class="container-fluid m-0 p-0">
			<div class="row">
				<div class="col-lg-9 col-md-12 mx-auto">
					<div class="card border-0 rounded-0">
						<span class="user-profile">
							<img src="../icons/user-profile.svg" alt="user profile">
							<span><?= $row["user_name"] ?></span>
						</span>
						<button class="btn btn-sm btn-secondary shadow rounder follow"
						        type="submit">FOLLOW
						</button>
						<img src=" ../img/<?= $row['img'] ?>" class="card-img-top shadow-sm rounder"
						     alt="nothing image">
						<div class="card-body">
							<div>
								<button class="like-btn" name="like">
									<img src="../icons/heart-dislike.svg" class="icons like" alt="like">
								</button>
								<img src="../icons/instagram-comment.svg" class="icons comment" alt="comment">
								<img src="../icons/send.svg" class="icons send" alt="sand">
								<img src="../icons/unsave.svg" class="icons save" alt="save">
							</div>
							<p class="card-text like-text">
								<?php
									$like_id = $row["id"];
									$checked_like = "SELECT * FROM post_likes
													WHERE post_id='$like_id' AND user_id='$user_id'";
									$checked_result = mysqli_query($con, $checked_like);
									if (mysqli_num_rows($checked_result) > 0) {
										while ($checked_row = mysqli_fetch_assoc($checked_result)) {
											?>
											<script>
												likeBtn = document.querySelectorAll(".like");
												for (let i = 0; i < likeBtn.length; i++) {
													console.log(likeBtn[i]);
													if (likeBtn[i].src.match("../icons/heart-dislike.svg")) {
														likeBtn[i].src = "../icons/heart-like.svg";
													}
												}
											</script>
											<?php
										}
									}
								?>
								<span class="count_like"><?= $row["count_like"] ?></span> likes
							</p>
							<p class="card-text comment-text">
								<span class="user_comment"><?= $row["user_name"] ?></span>
								<?= $row["comments"] ?>
							</p>
							<div class="sub-comment">
								<input type="hidden" name="img-id" id="img-id" value="<?= $row['id'] ?>">
								<?php
									$img_id = $row["id"];
									$select_comments = "SELECT * FROM new_comments
														INNER JOIN users ON (new_comments.user_id = users.user_id)
														WHERE img_id='$img_id'";
									$res = mysqli_query($con, $select_comments);
									if (mysqli_num_rows($res) > 0) {
										while ($comt_row = mysqli_fetch_assoc($res)) {
											?>
											<p class="sub-user-comment"><?= $comt_row["user_name"] ?>
												<span class="new-sub-comment"><?= $comt_row["comments"]; ?></span>
											</p>
											<?php
										}
									}
								?>
							</div>
							<div class="comment-box">
								<input type="text" class="new-comment" name="new-comment"
								       placeholder="Comment">
								<button class="mx-lg-3" name="add-comment">
									<img src="../icons/add-comment.svg" class="icons add-comt" alt="add comment">
								</button>
							</div>
							<p class="card-text post-time">uploaded <span><?= $customize_time ?></span></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php
		}
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "0 results.",
				icon: "warning",
				button: "OK",
			});
		</script>
	<?php
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Please login first.",
				icon: "warning",
				button: "OK",
			}).then(function () {
				location.href = "./login.php";
			});
		</script>
		<?php
	}
	mysqli_close($con);
?>
<script src="../js/home.js"></script>
<script !src="">
	$(".menu").on("click", function () {
		$(".list").toggleClass("hidden");
	});
</script>
</body>
</html>