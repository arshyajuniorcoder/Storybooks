<?php
	include "connectToDB.php";
	global $con;
	$like_id = $_POST["like_id"];
	$user_id = $_POST["user_id"];
	$select_likes = "SELECT * FROM post_likes WHERE post_id='$like_id' AND user_id='$user_id'";
	$likes_result = mysqli_query($con, $select_likes);
	if (mysqli_num_rows($likes_result) > 0) {
		while ($likes_row = mysqli_fetch_assoc($likes_result)) {
			if ($likes_row["sub"] == "LIKE") {
				$del_like = "DELETE FROM post_likes WHERE post_id='$like_id' AND user_id='$user_id'";
				mysqli_query($con, $del_like);
				$decrement = "UPDATE posts SET count_like=count_like-1 WHERE id='$like_id'";
				mysqli_query($con, $decrement);
			}
		}
	} else {
		$insert_like = "INSERT INTO post_likes(sub, user_id, post_id) VALUES
                                                     ('DISLIKE', '$user_id', '$like_id')";
		mysqli_query($con, $insert_like);
		$select_likes = "SELECT * FROM post_likes WHERE post_id='$like_id' AND user_id='$user_id'";
		$likes_result = mysqli_query($con, $select_likes);
		if (mysqli_num_rows($likes_result) > 0) {
			while ($likes_row = mysqli_fetch_assoc($likes_result)) {
				if ($likes_row["sub"] == "DISLIKE") {
					$update_to_like = "UPDATE post_likes SET sub='LIKE' WHERE post_id='$like_id'";
					mysqli_query($con, $update_to_like);
					$increment = "UPDATE posts SET count_like=count_like+1 WHERE id='$like_id'";
					mysqli_query($con, $increment);
				}
			}
		}
	}
	$select = "SELECT * FROM posts WHERE id='$like_id'";
	$result = mysqli_query($con, $select);
	$row = mysqli_fetch_assoc($result);
	echo $row["count_like"];