<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>LOGIN</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/login.css">
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark justify-content-between">
	<div class="container">
		<a class="navbar-brand logo-title">
			<img src="../icons/logo.png" class="d-inline-block align-top logo" alt="logo">
			<span>Story Book</span>
		</a>
		<form action="../index.php" method="post" class="form-inline">
			<button class="btn btn-sm btn-outline-danger mx-2" type="submit" name="back">BACK</button>
		</form>
	</div>
</nav>
<div class="wrapper">
	<div class="form-logo">
		<img src="../icons/logo.png" alt="logo">
	</div>
	<div class="text-center mt-4 name">Story Book</div>
	<form action="" method="post" class="p-3 mt-3">
		<div class="form-field d-flex align-items-center">
			<img src="../icons/user.svg" class="icons-sign" alt="user">
			<input type="text" name="username" placeholder="Username">
		</div>
		<div class="form-field d-flex align-items-center">
			<img src="../icons/key.svg" class="icons-sign" alt="key">
			<input type="password" name="password" placeholder="Password">
		</div>
		<button type="submit" class="btn mt-3" name="login">Login</button>
	</form>
	<div class="text-center fs-6">
		<a href="forgotPassword.php">Forget password?</a>
		or
		<a href="signup.php">Sign up</a>
	</div>
</div>
<?php
	include "connectToDB.php";
	global $con;
	if (isset($_POST["login"])) {
		$user_name = $_POST["username"];
		$password = $_POST["password"];
		$select_query = "SELECT * FROM users WHERE user_name='$user_name' AND pass_word='$password'";
		$result = mysqli_query($con, $select_query);
		if (mysqli_num_rows($result) > 0) {
			setcookie("user-name", $user_name);
			setcookie("pass-word", $password);
			?>
			<script>
				swal({
					title: "",
					text: "Welcome <?= $user_name ?>.",
					icon: "success",
					button: "OK",
				}).then(function () {
					<?php
					while ($row = mysqli_fetch_assoc($result)) {
					setcookie("user-id", $row["user_id"]);
					?>
					location.href = "./home.php";
					<?php
					}
					?>
				});
			</script>
		<?php
			} else {
		?>
			<script>
				swal({
					title: "",
					text: "username or password incorrect.",
					icon: "warning",
					button: "Try again",
				});
			</script>
			<?php
		}
	}
	mysqli_close($con);
?>
</body>
</html>