<?php
	if (isset($_POST["home"])) {
		header("Location: home.php");
	}
	if (isset($_POST["post"])) {
		header("Location: post.php");
	}
	if (isset($_POST["explore"])) {
		header("Location: explore.php");
	}
	if (isset($_POST["message"])) {
		header("Location: message.php");
	}
	if (isset($_POST["account"])) {
		header("Location: account.php");
	}
	if (isset($_POST["logout"])) {
		setcookie("user-id", null, -1);
		setcookie("user-name", null, -1);
		setcookie("pass-word", null, -1);
		setcookie("selected_user", null, -1);
		header("Location: login.php");
	}