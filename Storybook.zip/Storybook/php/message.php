<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>MESSAGE</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/menu.css">
	<link rel="stylesheet" href="../styles/message.css">
	<script src="../js/jquery-3.6.0.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
	include "../html/header.html";
	include "connectToDB.php";
	global $con;
	include "checkSignInUser.php";
	global $checked_sign;
	if ($checked_sign) {
	if (isset($_COOKIE["user-id"])) {
	include "menu.php";
	$user_id = $_COOKIE["user-id"];
	if (isset($_POST["send-message"])) {
		$selected_user = $_COOKIE["selected_user"];
		$messages = $_POST["messages"];
		date_default_timezone_set("Asia/Tehran");
		$message_time = date("Y-m-d H:i:s");
		$select_user_receiver = "SELECT * FROM users WHERE user_name='$selected_user'";
		$result = mysqli_query($con, $select_user_receiver);
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$user_receiver = $row["user_id"];
				$insert_message = "INSERT INTO messages(user_id_sender, user_message,
                     user_id_receiver, message_date) VALUES
                     ('$user_id', '$messages', '$user_receiver', '$message_time')";
				mysqli_query($con, $insert_message);
			}
		}
	}
?>
<div class="container">
	<div class="row rounded-lg overflow-hidden shadow message-box">
		<div class="col-md-4 p-0">
			<div class="bg-gray px-4 py-2">
				<p class="h5 py-3">Message</p>
			</div>
			<div class="list-group rounded-0">
				<div class="users-box">
					<?php
						$select_users = "SELECT * FROM users WHERE NOT user_id='$user_id'";
						$result = mysqli_query($con, $select_users);
						if (mysqli_num_rows($result) > 0) {
							while ($row = mysqli_fetch_assoc($result)) {
								?>
								<a class="list-group-item rounded-0 users">
									<img src="../icons/user-profile.svg" class="rounded-circle" alt="user" width="50">
									<span><?= $row["user_name"] ?></span>
								</a>
								<?php
							}
						}
					?>
				</div>
			</div>
		</div>
		<div class="col-md-8 bg-white p-0">
			<?php
				if (isset($_COOKIE["selected_user"])) {
					$selected_user = $_COOKIE["selected_user"];
					$select_users = "SELECT * FROM users WHERE user_name='$selected_user'";
					$result = mysqli_query($con, $select_users);
					if (mysqli_num_rows($result) > 0) {
						while ($row = mysqli_fetch_assoc($result)) {
							?>
							<div class="bg-white user-profile">
								<img src="../icons/user-profile.svg" class="rounded-circle" alt="user">
								<span><?= $row["user_name"] ?></span>
							</div>
							<?php
						}
					}
				}
				if (isset($_POST["transfer_user"])) {
					$transfer_user = $_POST["transfer_user"];
					$select_users = "SELECT * FROM users WHERE user_name='$transfer_user'";
					$result = mysqli_query($con, $select_users);
					if (mysqli_num_rows($result) > 0) {
						while ($row = mysqli_fetch_assoc($result)) {
							if ($row["user_id"] != $user_id) {
								?>
								<div class="bg-white user-profile">
									<img src="../icons/user-profile.svg" class="rounded-circle" alt="user">
									<span><?= $row["user_name"] ?></span>
								</div>
								<?php
							} else {
							}
						}
					}
				}
			?>
			<div class="bg-white px-4 chat-box">
				<?php
					if (isset($_COOKIE["selected_user"])) {
						$selected_user = $_COOKIE["selected_user"];
						?>
						<div class="chat-body">
							<?php
								$select_user_receiver = "SELECT * FROM users WHERE user_name='$selected_user'";
								$result = mysqli_query($con, $select_user_receiver);
								if (mysqli_num_rows($result) > 0) {
									while ($row = mysqli_fetch_assoc($result)) {
										$user_receiver = $row["user_id"];
										$select_send_message = "SELECT * FROM messages
											WHERE (user_id_sender='$user_id' AND user_id_receiver='$user_receiver') 
                          					OR (user_id_sender='$user_receiver' AND user_id_receiver='$user_id')
											ORDER BY message_date";
										$result_send = mysqli_query($con, $select_send_message);
										if (mysqli_num_rows($result_send) > 0) {
											while ($row = mysqli_fetch_assoc($result_send)) {
												$message_time = strtotime($row["message_date"]);
												$customize_time = date("l, d F, Y", $message_time);
												if ($row["user_id_sender"] == $user_id) {
													?>
													<div class="w-100">
														<div class="w-50 rounded sender-user">
															<p class="text-muted mb-0 sender-message">
																<?= $row["user_message"] ?>
															</p>
															<span class="text-small text-muted sender-date">
														<?= $customize_time ?>
													</span>
														</div>
													</div>
													<?php
												} else {
													?>
													<div class="w-100 receiver">
														<div class="w-50 bg-primary rounded receiver-user">
															<p class="mb-0 receiver-message">
																<?= $row["user_message"] ?>
															</p>
															<span class="text-small receiver-date">
														<?= $customize_time ?>
													</span>
														</div>
													</div>
													<?php
												}
											}
										}
									}
								}
							?>
						</div>
						<div class="typing-message">
							<form action="" method="post" class="input-group">
								<input type="text" class="form-control message-input" name="messages"
								       placeholder="Type a message">
								<button class="btn btn-link" name="send-message" type="submit">
									<i class="fa fa-paper-plane"></i>
								</button>
							</form>
						</div>
						<?php
					}
					if (isset($_POST["transfer_user"])) {
						$transfer_user = $_POST["transfer_user"];
						?>
						<div class="chat-body">
							<?php
								$select_user_receiver = "SELECT * FROM users WHERE user_name='$transfer_user'";
								$result = mysqli_query($con, $select_user_receiver);
								if (mysqli_num_rows($result) > 0) {
									while ($row = mysqli_fetch_assoc($result)) {
										if ($row["user_id"] != $user_id) {
											$user_receiver = $row["user_id"];
											$select_send_message = "SELECT * FROM messages
											WHERE (user_id_sender='$user_id' AND user_id_receiver='$user_receiver') 
                          					OR (user_id_sender='$user_receiver' AND user_id_receiver='$user_id')
											ORDER BY message_date";
											$result_send = mysqli_query($con, $select_send_message);
											if (mysqli_num_rows($result_send) > 0) {
												while ($row = mysqli_fetch_assoc($result_send)) {
													$message_time = strtotime($row["message_date"]);
													$customize_time = date("l, d F, Y", $message_time);
													if ($row["user_id_sender"] == $user_id) {
														?>
														<div class="w-100">
															<div class="w-50 rounded sender-user">
																<p class="text-muted mb-0 sender-message">
																	<?= $row["user_message"] ?>
																</p>
																<span class="text-small text-muted sender-date">
														<?= $customize_time ?>
													</span>
															</div>
														</div>
														<?php
													} else {
														?>
														<div class="w-100 receiver">
															<div class="w-50 bg-primary rounded receiver-user">
																<p class="mb-0 receiver-message">
																	<?= $row["user_message"] ?>
																</p>
																<span class="text-small receiver-date">
														<?= $customize_time ?>
													</span>
															</div>
														</div>
														<?php
													}
												}
											}
										} else {
										}
									}
								}
							?>
						</div>
						<?php
						$select_user_receiver = "SELECT * FROM users WHERE user_name='$transfer_user'";
						$result = mysqli_query($con, $select_user_receiver);
						if (mysqli_num_rows($result) > 0) {
							while ($row = mysqli_fetch_assoc($result)) {
								if ($row["user_id"] != $user_id) {
									?>
									<div class="typing-message">
										<form action="" method="post" class="input-group">
											<input type="text" class="form-control message-input" name="messages"
											       placeholder="Type a message">
											<button class="btn btn-link" name="send-message" type="submit">
												<i class="fa fa-paper-plane"></i>
											</button>
										</form>
									</div>
									<?php
								}
							}
						}
					}
				?>
			</div>
		</div>
	</div>
	<?php
		}
		}
		mysqli_close($con);
	?>
	<script src="../js/message.js"></script>
	<script !src="">
		$('.menu').on('click', function () {
			$('.list').toggleClass('hidden');
		});
	</script>
</body>
</html>