<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>POST</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link rel="stylesheet"
	      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/menu.css">
	<link rel="stylesheet" href="../styles/post.css">
	<script src="../js/jquery-3.6.0.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<?php
	include "../html/header.html";
	include "connectToDB.php";
	global $con;
	include "checkSignInUser.php";
	global $checked_sign;
	if ($checked_sign) {
		include "menu.php";
		?>
		<div class="container w-100">
			<div class="upload-file">
				<form action="" method="post" class="input-group upload-form" enctype="multipart/form-data">
					<div class="row text-center">
						<div class="col-12 mb-3">
							<input type="file" class="form-control files" name="img">
						</div>
						<div class="col-12 mb-5">
							<textarea class="form-control" placeholder="Comments" name="comment"></textarea>
						</div>
						<div class="col-12">
							<button type="submit" class="btn btn-outline-primary rounded m-auto px-5" name="submit">
								Submit
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	<?php
		if (isset($_POST["submit"]) && isset($_COOKIE["user-id"])) {
		$dir = "../img/";
		$img = $_FILES["img"];
		$dirAddress = $dir . $img["name"];
		$filename = strtolower(pathinfo($dirAddress, PATHINFO_FILENAME));
		$extension = strtolower(pathinfo($dirAddress, PATHINFO_EXTENSION));
		$uploaded = 1;
		$comments = $_POST["comment"];
		if ($extension != "jpg" && $extension != "png" && $extension != "jpeg"
	&& $extension != "gif") {
	?>
		<script>
			swal({
				title: "",
				text: "Sorry, only JPG, JPEG, PNG & GIF files are allowed.",
				icon: "warning",
				button: "Try again",
			});
		</script>
	<?php
		$uploaded = 0;
		}
		if ($uploaded == 0) {
			return;
		} else {
			$user_id = $_COOKIE["user-id"];
			date_default_timezone_set("Asia/Tehran");
			$post_time = date("Y-m-d H:i:s");
			if (file_exists($dirAddress)) {
				$finalFileName = $filename . '_' . rand(1, 1000000) . time() . '.' . $extension;
				move_uploaded_file($img["tmp_name"], $dir . $finalFileName);
				$insert_query = "INSERT INTO posts(img, comments, post_time, user_id) 
										VALUES ('$finalFileName', '$comments', '$post_time', '$user_id')";
			} else {
				move_uploaded_file($img["tmp_name"], $dirAddress);
				$img_name = $img["name"];
				$insert_query = "INSERT INTO posts(img, comments, post_time, user_id) 
										VALUES ('$img_name', '$comments', '$post_time', '$user_id')";
			}
		}
		if (mysqli_query($con, $insert_query)) {
	?>
		<script>
			swal({
				title: "",
				text: "New record created successfully.",
				icon: "success",
				button: "OK",
			}).then(function () {
				location.href = "./home.php";
			});
		</script>
	<?php
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "No information added to sql.",
				icon: "error",
				button: "Try again",
			});
		</script>
	<?php
		}
		}
		} else {
	?>
		<script>
			swal({
				title: "",
				text: "Please login first.",
				icon: "warning",
				button: "OK",
			}).then(function () {
				location.href = "./login.php";
			});
		</script>
		<?php
	}
	mysqli_close($con);
?>
<script !src="">
	$('.menu').on('click', function () {
		$('.list').toggleClass('hidden');
	});
</script>
</body>
</html>