<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>SIGNUP</title>
	<link rel="stylesheet" href="../styles/bootstrap/css/bootstrap.css">
	<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet'>
	<link rel="stylesheet" href="../styles/header.css">
	<link rel="stylesheet" href="../styles/signup.css">
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark justify-content-between">
	<div class="container">
		<a class="navbar-brand logo-title">
			<img src="../icons/logo.png" class="d-inline-block align-top logo" alt="logo">
			<span>Story Book</span>
		</a>
		<form action="../index.php" method="post" class="form-inline">
			<button class="btn btn-sm btn-outline-danger mx-2" type="submit" name="back">BACK</button>
		</form>
	</div>
</nav>
<div class="wrapper">
	<div class="form-logo">
		<img src="../icons/logo.png" alt="logo">
	</div>
	<div class="text-center mt-4 name">Story Book</div>
	<form action="" method="post" class="p-3 mt-3">
		<div class="form-field d-flex align-items-center">
			<img src="../icons/user.svg" class="icons-sign" alt="user">
			<input type="text" name="username" placeholder="Username">
		</div>
		<div class="form-field d-flex align-items-center">
			<img src="../icons/key.svg" class="icons-sign" alt="key">
			<input type="password" name="password" placeholder="Password">
		</div>
		<div class="form-field d-flex align-items-center">
			<img src="../icons/key.svg" class="icons-sign" alt="confirm-key">
			<input type="password" name="confirm-password" placeholder="Confirm Password">
		</div>
		<button class="btn mt-3" name="signup">Sign up</button>
	</form>
	<div class="text-center fs-6">
		<a href="login.php">Login</a>
	</div>
</div>
<?php
	include "connectToDB.php";
	global $con;
	if (isset($_POST["signup"])) {
		$user_name = $_POST["username"];
		$password = $_POST["password"];
		$confirm_password = $_POST["confirm-password"];
		$select_username = "SELECT * FROM users WHERE user_name='$user_name'";
		$result_username = mysqli_query($con, $select_username);
		if (mysqli_num_rows($result_username) > 0) {
			?>
			<script>
				swal({
					title: "",
					text: "Sorry, username already taken.",
					icon: "error",
					button: "Try again",
				});
			</script>
		<?php
			} else {
			if (strlen($password) > 3) {
			if ($password == $confirm_password) {
			$insert_query = "INSERT INTO users(user_name, pass_word)
							VALUES ('$user_name', '$password')";
			if (mysqli_query($con, $insert_query)) {
		?>
			<script>
				swal({
					title: "",
					text: "You have successfully registered.",
					icon: "success",
					button: "OK",
				}).then(function () {
					location.href = "./login.php";
				});
			</script>
		<?php
			} else {
		?>
			<script>
				swal({
					title: "",
					text: "Sorry, there was a problem with your registration, please try again.",
					icon: "error",
					button: "Try again",
				});
			</script>
		<?php
			}
			} else {
		?>
			<script>
				swal({
					title: "",
					text: "Passwords are not the same.",
					icon: "warning",
					button: "Try again",
				});
			</script>
		<?php
			}
			} else {
		?>
			<script>
				swal({
					title: "",
					text: "Your password is less than four characters long.",
					icon: "warning",
					button: "Try again",
				});
			</script>
			<?php
		}
		}
	}
	mysqli_close($con);
?>
</body>
</html>