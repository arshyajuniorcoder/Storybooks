-- CREATE DATABASE storybook_project;
USE epiz_31543548_storybook;
CREATE TABLE users (
    user_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(100) NOT NULL,
    pass_word VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NULL,
    last_name VARCHAR(50) NULL,
    email VARCHAR(200) NULL,
    phone_no VARCHAR(15) NULL,
    gender ENUM("female", "male", "other") NULL
);
CREATE TABLE posts (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    img VARCHAR(500) NOT NULL,
    comments VARCHAR(1000) NULL,
    post_time DATETIME NOT NULL,
    user_id INT NOT NULL,
    count_like INT NULL DEFAULT 0,
    CONSTRAINT FK_UserPost FOREIGN KEY (user_id)
        REFERENCES users (user_id)
);
CREATE TABLE new_comments (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    comments VARCHAR(1000) NOT NULL,
    user_id INT NOT NULL,
    img_id INT NOT NULL,
    CONSTRAINT FK_UserComment FOREIGN KEY (user_id)
        REFERENCES users (user_id),
    CONSTRAINT FK_ImgComment FOREIGN KEY (img_id)
        REFERENCES posts (id)
);
CREATE TABLE post_likes (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sub ENUM('DISLIKE', 'LIKE') NULL,
    user_id INT NOT NULL,
    post_id INT NOT NULL,
    CONSTRAINT FK_UserLike FOREIGN KEY (user_id)
        REFERENCES users (user_id),
    CONSTRAINT FK_PostLike FOREIGN KEY (post_id)
        REFERENCES posts (id)
);
CREATE TABLE messages (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id_sender INT NULL,
    user_message VARCHAR(1000) NULL,
    user_id_receiver INT NULL,
    message_date DATETIME NULL,
    CONSTRAINT FK_UserSender FOREIGN KEY (user_id_sender)
        REFERENCES users (user_id),
    CONSTRAINT FK_UserReceiver FOREIGN KEY (user_id_receiver)
        REFERENCES users (user_id)
);